# GU Orbit website

This is the website of GU Orbit.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
npm install
```

## Usage

```bash
cd website
npm run serve
```

## License
[MIT](https://choosealicense.com/licenses/mit/)
